window.onload = function()
{
    CKEDITOR.replace( 'cms_desc' );
    CKEDITOR.replace( 'cms_shortdesc' );
};