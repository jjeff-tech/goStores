$(document).ready(function(){
//    $('#banner').bjqs({
//        'animation' : 'slide',
//        'width' : 400,
//        'height' : 200
//
//    });
    
//    $("#jqtxtStoreName").click(function(){alert('jqtxtStoreName');
//        if ($(this).val() = "") {
//            $("#jqtxtStoreName").val("Store Name");
//        }
//        else if ($(this).val() = "Store Name"){
//            $("#jqtxtStoreName").val("");
//        }
//    });
});