    $(document).ready(function(){
        $("#nav-one").dropmenu();
    });